import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(BankingApp());
}

class BankingApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.blue),
      home: SplashScreen(),
    );
  }
}
class SplashScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Navigate to LoginScreen after 3 seconds
    Future.delayed(const Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => LoginScreen()),
      );
    });

    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Background Image
          Image.asset(
            'assets/pexels-siddhartha-sen-14371386-29269990.jpg', // Path to the background image
            fit: BoxFit.cover, // Ensures the background image covers the entire screen
          ),
          // Overlay to make logo stand out more
          Container(
            color: Colors.black.withOpacity(0.7), // Semi-transparent black overlay
          ),
          // Logo and Loading Indicator
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Bank Logo - Increase the size here
                Image.asset(
                  'assets/nmblogo.png', // Path to the logo image
                  width: 250, // Increased size of the logo
                  height: 250, // Increased size of the logo
                ),
                const SizedBox(height: 20), // Space between logo and loading indicator
                // Loading Indicator
                const CircularProgressIndicator(),
                const SizedBox(height: 20),
                const Text(
                  'Loading...',
                  style: TextStyle(fontSize: 18, color: Colors.white),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class LoginScreen extends StatelessWidget {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Login')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Username Text Field
            TextField(
              controller: _usernameController,
              decoration: const InputDecoration(labelText: 'Enter Username'),
            ),
            const SizedBox(height: 20),

            // Password Text Field
            TextField(
              controller: _passwordController,
              obscureText: true, // To hide the password input
              decoration: const InputDecoration(labelText: 'Enter Password'),
            ),
            const SizedBox(height: 20),

            // Login Button
            ElevatedButton(
              onPressed: () {
                // Validate the inputs and proceed
                if (_usernameController.text.isNotEmpty && _passwordController.text.isNotEmpty) {
                  // Here you can call an authentication API or perform local validation
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => AccountsScreen()), // Navigate to next screen
                  );
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Please enter both username and password')),
                  );
                }
              },
              child: const Text('Login'),
            ),
            const SizedBox(height: 10),

            // Forgot Password Link (optional)
            TextButton(
              onPressed: () {
                // Navigate to password reset screen (optional)
                // Navigator.push(context, MaterialPageRoute(builder: (context) => ForgotPasswordScreen()));
              },
              child: const Text('Forgot Password?'),
            ),
          ],
        ),
      ),
    );
  }
}

class AccountsScreen extends StatefulWidget {
  @override
  _AccountsScreenState createState() => _AccountsScreenState();
}

class _AccountsScreenState extends State<AccountsScreen> {
  List<Map<String, dynamic>> accounts = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchAccounts();
  }

  Future<void> fetchAccounts() async {
    try {
      final response = await http.get(Uri.parse('https://nawazchowdhury.com/acc.php'));

      if (response.statusCode == 200) {
        final jsonResponse = json.decode(response.body);

        setState(() {
          accounts = [
            if (jsonResponse['chequing'] != null)
              {'type': 'chequing', 'account': jsonResponse['chequing']},
            if (jsonResponse['savings'] != null)
              {'type': 'savings', 'account': jsonResponse['savings']},
          ];
          isLoading = false;
        });
      } else {
        showError('Failed to load accounts. Status code: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred while fetching accounts: $e');
    }
  }

  void showError(String message) {
    setState(() {
      isLoading = false;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Accounts')),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : accounts.isEmpty
              ? const Center(child: Text('No accounts available.'))
              : ListView.builder(
                  itemCount: accounts.length,
                  itemBuilder: (context, index) {
                    final account = accounts[index]['account'];
                    final type = accounts[index]['type'];
                    return Card(
                      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                      child: ListTile(
                        title: Text('$type Account: ${account['accountNumber']}'),
                        subtitle: Text('Balance: ${account['balance']} ${account['currency']}'),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => TransactionScreen(
                                url: type == 'savings'
                                    ? 'https://nawazchowdhury.com/sav.php'
                                    : 'https://nawazchowdhury.com/chq.php',
                              ),
                            ),
                          );
                        },
                      ),
                    );
                  },
                ),
    );
  }
}

class TransactionScreen extends StatefulWidget {
  final String url;

  TransactionScreen({required this.url});

  @override
  _TransactionScreenState createState() => _TransactionScreenState();
}

class _TransactionScreenState extends State<TransactionScreen> {
  List<dynamic> transactions = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchTransactions();
  }

  Future<void> fetchTransactions() async {
    try {
      final response = await http.get(Uri.parse(widget.url));

      if (response.statusCode == 200) {
        final jsonResponse = json.decode(response.body);

        setState(() {
          transactions = jsonResponse;
          isLoading = false;
        });
      } else {
        showError('Failed to load transactions. Status code: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred while fetching transactions: $e');
    }
  }

  void showError(String message) {
    setState(() {
      isLoading = false;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Transactions')),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : transactions.isEmpty
              ? const Center(child: Text('No transactions available.'))
              : ListView.builder(
                  itemCount: transactions.length,
                  itemBuilder: (context, index) {
                    final transaction = transactions[index];
                    return Card(
                      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                      child: ListTile(
                        title: Text('Description: ${transaction['description']}'),
                        subtitle: Text('Amount: ${transaction['amount']}'),
                        trailing: Text('Date: ${transaction['date']}'),
                      ),
                    );
                  },
                ),
    );
  }
}
